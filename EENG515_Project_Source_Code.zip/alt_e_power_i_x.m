function v = alt_e_power_i_x(x, metric_handle)

    v = alt_cos(x, metric_handle) + sqrt(-1)*alt_sin(x, metric_handle);

end